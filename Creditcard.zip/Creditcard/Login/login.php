<?php
    include("../db.php");
    session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
	if(!$conn)
	{
		die("Database Connection Failed" .mysqli_error($connection));
	}
	    if(isset($_POST['email']) and isset($_POST['password']))
	{
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		
			$query = "Select * FROM admin_details WHERE admin_mail='$email' and admin_pass='$password'";
			
			$result = mysqli_query($conn,$query) or die(mysqli_error($conn));
			
			$count = mysqli_num_rows($result);					
			if($count==0)
			{
				echo ('<script>alert("Invalid Username or Password")</script>');
				$j = "select attempts from admin_details where admin_mail='$email'";
				$r = mysqli_query($conn,$j);
				$value = mysqli_fetch_assoc($r);
				
				
				if($value["attempts"]==0)
				{
					$i="update admin_details set attempts=1 where admin_mail='$email'";
			        	$status = mysqli_query($conn,$i);
					echo "you have done 1 wrong attempts";
					header( "refresh:5.0;url=login.php" );
				}
				if($value["attempts"]==1)
				{
					$i="update admin_details set attempts=2 where admin_mail='$email'";
			        	$status = mysqli_query($conn,$i);
					echo "you have done 2 wrong attempts";
					header( "refresh:5.0;url=login.php" );
					if (isset($_POST["btn_login"]))
{
$email=$_POST['email'] ;
$_SESSION['email']=$email;
$admin="Select * from admin_details where admin_mail='$email'";
$adminresult=$conn->query($admin);
$admincnt=mysqli_num_rows($adminresult);
       if($admincnt==1)
      {
       $abc="select * from admin_details where admin_mail='$email'";
       $q=mysqli_query($conn,"$abc");
       // echo $abc."<br><br>";
       $count= mysqli_num_rows($q);
        if($count>0)
        {
            require 'vendor/autoload.php';

            $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
           
            try {
                //Server settings
                $mail->SMTPDebug =0;                                 // Enable verbose debug output
                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = TRUE;                               // Enable SMTP authentication
                $mail->Username = 'email id';                 // SMTP username
                $mail->Password = 'password';                           // SMTP password
                $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 25;                                    // TCP port to connect to
                //Recipients
                $mail->setFrom('email id', 'People Generated News');
                $mail->addAddress($email, $email);     // Add a recipient
                //Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Failed login credential';
                $mail->Body = "Hi, $email.<br><center> Your <b>2 failed</b> login attempt is done only 1 attempt is left <b></b></center>";
               // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                 
                $mail->send();
                echo "<script>alert('Mail has been sent for 2nd wrong attempt');window.location='login.php';</script>";
            }
            catch (Exception $e)
            {
                echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
            }
        }
        else
        {
            echo "<script>alert('Email Not Found');</script>";
        }
      }        
      else
      {
                echo "<script>alert('Email not in System')</script>";
      }
    }

					
				}
				if($value["attempts"]==2)
				{
					$i="update admin_details set attempts=3 where admin_mail='$email'";
			        	$status = mysqli_query($conn,$i);
					echo "you have done 3 wrong attempts";
					header( "refresh:5.0;url=login.php" );
					if (isset($_POST["btn_login"]))
{
$email=$_POST['email'] ;
$_SESSION['email']=$email;
$admin="Select * from admin_details where admin_mail='$email'";
$adminresult=$conn->query($admin);
$admincnt=mysqli_num_rows($adminresult);
       if($admincnt==1)
      {
       $abc="select * from admin_details where admin_mail='$email'";
       $q=mysqli_query($conn,"$abc");
       // echo $abc."<br><br>";
       $count= mysqli_num_rows($q);
        if($count>0)
        {
            require 'vendor/autoload.php';

            $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
           
            try {
                //Server settings
                $mail->SMTPDebug =0;                                 // Enable verbose debug output
                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = TRUE;                               // Enable SMTP authentication
                $mail->Username = 'email id';                 // SMTP username
                $mail->Password = 'password';                           // SMTP password
                $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 25;                                    // TCP port to connect to
                //Recipients
                $mail->setFrom('email id', 'People Generated News');
                $mail->addAddress($email, $email);     // Add a recipient
                //Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Blocking your account';
                $mail->Body = "Hi, $email.<br><center> Your all login attempt is completed you have entered <b>3 failed</b> login credential.<br>So, Please contact bank admin to recover your account.<br>Sorry for inconvience.<b></b></center>";
               // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                 
                $mail->send();
                echo "<script>alert('Your account have been block');window.location='login.php';</script>";
            }
            catch (Exception $e)
            {
                echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
            }
        }
        else
        {
            echo "<script>alert('Email Not Found');</script>";
        }
      }        
      else
      {
                echo "<script>alert('Email not in System')</script>";
      }
    }
				}
				if($value["attempts"]==3)
				{
					$i="update admin_details set admin_pass = NULL where admin_mail='$email'";
			        	$status = mysqli_query($conn,$i);
					echo "<center><h1>You are banned from the server!! Contact your system administrator to unlock your attempts or reset your password.</h1?</center>";
					header("refresh:1.0;url=ban.html");
				}
			}
			else
			{
					echo ('<script>alert("Welcome")</script>');
				    	echo("You've been logged in successfully!!");
					$i="update admin_details set attempts=0 where admin_mail='$email'";
			        	$status = mysqli_query($conn,$i);	
					header( "refresh:10.0;url=dashboard.html" );
			}	
	}	    
?>
<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- <title>Popup Login Form Design | CodingNepal</title> -->
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
<body class="form">
    <div class="center">
      <input type="checkbox" id="show">
      <label for="show" class="show-btn">Click here</label>
      <div class="container">
        <label for="show" class="close-btn fas fa-times" title="close"></label>
        <h1 class="">Login Form</h1>
		<p class="">Log in to your account to continue.</p> 
        <form class="text-left" method="post">
        
		<div class="data">
			<input id="email" name="email" type="email" class="form-control" placeholder="Enter your Mail" required>
        </div>
		<div class="data">
			<input id="password" name="password" type="password" class="form-control" placeholder="Password" required>
        </div>
		<div class="forgot-pass-link">
		<a href="repass.php">Forgot Password?</a></div>
		<div class="btn btn-primary">
		<div class="inner"></div>
		<button type="submit" name="btn_login">login</button>
<?php
if (isset($_POST["btn_login"]))
{
    $email = $_POST["email"];
    $pass = $_POST["password"];
    $admin_qry="select * from admin_details where admin_mail = '$email' and admin_pass = '$pass'";
    $a_fire=$conn->query($admin_qry);
    $a_cnt=mysqli_num_rows($a_fire);
    if ($a_cnt == 1)
    {
        $a_res=$a_fire->fetch_assoc();
        $_SESSION["admin_id"] = $a_res["admin_id"];
        $_SESSION["login"] = 1;
        echo ("<script>location.href='dashboard.html'</script>");
    }
    else
    {
        echo "mail or password is worng";
    }
}
?>
           </form>
		   </div>
</div>
</body>
</html>