<?php
include("../db.php");

session_start();
$rotp="";
$getotp="";
$rotp=$_SESSION['otp'];
// echo $rotp;
if(!isset($_SESSION['otp']))
{
    header("location:password-reset.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body class="form no-image-content">
    <div class="form-container outer">
        <div class="form-form">
            <div class="form-form-wrap">
                <div class="form-container">
                    <div class="form-content">

                        <h1 class="">OTP - One Time Password</h1>
                        <p class="signup-link recovery">Enter your otp to change your password</p>
                        <form class="text-left" method="post">
                            <div class="form">

                                <div id="email-field" class="field-wrapper input">
                                    <div class="d-flex justify-content-between">
                                        <label for="email">OTP</label>
                                    </div>
                                    <!-- <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-at-sign"><circle cx="12" cy="12" r="4"></circle><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"></path></svg> -->
                                    <input id="otp" name="txt_otp" type="text" class="form-control" value="" placeholder="Enter Your OTP">
                                </div>

                                <div class="d-sm-flex justify-content-between">

                                    <div class="field-wrapper">
                                        <button type="submit" class="btn btn-primary" name="btn_reset">Check</button>
                                    </div>
                                </div>

                            </div>
                        </form>




<?php
if (isset($_POST["btn_reset"]))
{
    $getotp=$_POST["txt_otp"];
    // echo $getotp;
    if($getotp==$rotp)
    {
        echo "<script>alert('match');</script>";
       header("location:newpass.php");
    }
 else
    {
          echo "<script>alert('OTP not match ..');</script>";
    }
}
?>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
</body>
</html>