<?php
include("../db.php");

session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
*{
  margin: 0px;
  padding: 0px;
  outline: none;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body{
  height: 100%;
  width: 100%;
  background: linear-gradient(115deg, #56d8e4 10%, #9f01ea 90%);
}
h1,form{
	align: center;
	padding: 10px; }
<meta charset="utf-8">
    <!-- <title>Popup Login Form Design | CodingNepal</title> -->
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</style>
</head>
<body class="form" align="center">
			
		      
		      <div class="container">
        	      <label for="show" class="close-btn fas fa-times" title="close"></label>
        		<h1 class="">Password recovery</h1>
			<p class="">Enter your email and instructions will sent to you!</p> 
	
                        <form class="text-left" method="post">      
				    <div class="data">
				    <input id="email" name="email" type="email" class="form-control" placeholder="Enter your Mail" required><br><br>
        			</div>                        
				    <div class="btn btn-primary">
				    <div class="inner"></div>                                              
				    <button type="submit" class="btn btn-primary" name="btn_reset">Reset</button>
                        </form>

<?php
if (isset($_POST["btn_reset"]))
{
$email=$_POST['email'] ;
$_SESSION['email']=$email;
$admin="Select * from admin_details where admin_mail='$email'";
$adminresult=$conn->query($admin);
$admincnt=mysqli_num_rows($adminresult);
       if($admincnt==1)
      {
       $abc="select * from admin_details where admin_mail='$email'";
       $q=mysqli_query($conn,"$abc");
       // echo $abc."<br><br>";
       $count= mysqli_num_rows($q);
       // echo $count;
       $row= mysqli_fetch_array($q);
       $otp= rand(100000,900000);
       $_SESSION['otp']=$otp;
      
        if($count>0)
        {
            require 'vendor/autoload.php';

            $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
           
            try {
                //Server settings
                $mail->SMTPDebug =0;                                 // Enable verbose debug output
                $mail->isSMTP();                                      // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = TRUE;                               // Enable SMTP authentication
                $mail->Username = 'email id';                 // SMTP username
                $mail->Password = 'your password';                           // SMTP password
                $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
                $mail->Port = 25;                                    // TCP port to connect to
                //Recipients
                $mail->setFrom('email id', 'People Generated News');
                $mail->addAddress($email, $email);     // Add a recipient
                //Content
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Forget Password';
                $mail->Body = "Hi, $email.<br><center> Your <b>OTP</b> is <b>$otp</b></center>";
               // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                 
                $mail->send();
                echo "<script>alert('OTP Has Been Send To Your Email');window.location='otp.php';</script>";
            }
            catch (Exception $e)
            {
                echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
            }
        }
        else
        {
            echo "<script>alert('Email Not Found');</script>";
        }
      }        
      else
      {
                echo "<script>alert('Email not in System')</script>";
      }
    }
?>
</div>
</div>
</body>
</html>